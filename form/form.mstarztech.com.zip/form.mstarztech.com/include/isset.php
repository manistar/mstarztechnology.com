<?php
    if(isset($_POST['submit_form'])){
        $p->form_assessment();
    }
?>