<?php
    // $profile = $d->fastgetwhere("form_data", "fname = ?",);
?>