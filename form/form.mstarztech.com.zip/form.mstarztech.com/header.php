<?php 
    require_once "include/database.php";
    $d = new database;

    require_once "function/server.php";
    $p = new project;
?>

<style>
    .ref {
        color: brown;
    }
</style>

